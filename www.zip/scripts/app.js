'use strict';

angular.module('main', [
  'ionic',
  'ngCordova',
  'ui.router',
  // TODO: load other modules selected during generation
]);


'use strict';
/*eslint-disable no-unused-vars */
function findCategory (results, findId) {
  for (var i = 0; i < results.length; i++) {
    if (results[i].category_id === findId) {
      //console.log(results[i].category_id);
      return results[i];
    } else {
      var subcat = results[i].subCollection;
      if (subcat !== null) {
        for (var j = 0; j < subcat.length; j++) {
          if (subcat[j].category_id === findId) {
            //console.log(subcat[j].category_id);
            return subcat[j];
          }
        }
      }
    }
  }
}

function getParentCat (results, findId) {
  for (var i = 0; i < results.length; i++) {
    if (results[i].category_id === findId) {
      //console.log(results[i].toSource());
      return results[i];
    } else {
      var subcat = results[i].subCollection;
      if ( subcat !== null) {
        for (var j = 0; j < subcat.length; j++) {
          if (subcat[j].category_id === findId) {
            //console.log(subcat[j].category_id);
            //console.log(results[i].toSource());
            return results[i];
          }
        }
      }
    }
  }
}

function getAutoSuggest (results) {
  var rval = [];
  angular.forEach(results, function (obj) {
    rval.push({id: obj.category_id, title: obj.title});

    var subcat = obj.subCollection;
    if (subcat !== null) {
      angular.forEach(subcat, function (subObj) {
        rval.push({id: subObj.category_id, title: subObj.title});
      });
    }
  });

  return rval;
}

function getSelectedFilter (data, seletedArray, ftype) {
  angular.forEach(data, function (obj) {
    angular.forEach(seletedArray, function (id) {
      if (ftype === 'brands') {if (obj.brand_id === id) { obj.selected = true; }}
      if (ftype === 'price') {if (obj.pricefilter === id) { obj.selected = true; }}
      if (ftype === 'discount') {if (obj.discountfilter === id) { obj.selected = true; }}
    });
  });
  return data;
}

function toObject (arr) {
  var rv = {};
  for (var i = 0; i < arr.length; ++i) {
    rv[i] = arr[i];
  }
  return rv;
}


'use strict';
angular.module('delivery.services', ['ionic']);

'use strict';
angular.module('delivery.services')
.factory('usersService', function ($http) {
  var service = {
    userDetails: function () {
      return $http.get('data/delivery/user/account.json');
    },
    userLogout: function () {
      return $http.get('/data/delivery/user/logout.json');
    },
    getCountries: function () {
      return $http.get('/data/delivery/user/countries.json');
    },
  };
  return service;
});

'use strict';
function toObject (arr) {
  var rv = {};
  for (var i = 0; i < arr.length; ++i) {
    rv[i] = arr[i];
  }
  return rv;
}

angular.module('delivery.services')
.factory('productsService', function ($rootScope, $http) {
  var service = {
/*eslint-disable no-unused-vars */
    getProducts: function (catid, title, paged) {

/*RewriteRule ^api/rest/products/category/?([0-9]+)/limit/?([0-9]+)/page/?([0-9]+)/order/?([a-zA-Z]+)/sort/?([a-zA-Z]+)/filtersdata/?([0-9,-|]+)  [L]*/

/* var sortArray = $rootScope.sortProductBy.split('-');

  var paging= 5;
  if (paged>1) {paging = 10;}

  if (catid>0) {
    var fliter_val = '';
    var bf_val = service.getFilterData(catid,'brands');
    var pf_val = service.getFilterData(catid,'price');
    var df_val = service.getFilterData(catid,'discount');
    if (bf_val!='' || pf_val!='' || df_val!='' ) {fliter_val = bf_val + '|' + pf_val + '|' + df_val;}

    if(fliter_val!=''){
      var apiURL = '/data/delivery/product/productsfl'+catid+'-'+paging+'-'+paged+'-'+sortArray[1]+'-'+sortArray[0]+'-filter'+fliter_val;
    }else{
      var apiURL = '/data/delivery/product/products'+catid+'-'+paging+'-'+paged+'-'+sortArray[1]+'-'+sortArray[0];
    }
  } else {
    var apiURL = '/data/delivery/product/productsr'+title+'-10-'+paged+'-'+sortArray[1]+'-'+sortArray[0];
  }
  var showloader = 'Y'; if(paged>1)showloader = 'N';*/
      return $http.get('data/delivery/product/products1-5-1-ASC-name.json');
    },
    getProductDetail: function (prodId) {
      return $http.get('data/delivery/product/detail.json');
    },
    getFilterOptions: function (catId) {
      return $http.get('data/delivery/product/filter.json');
    },
    setFilterData: function (catId, ftype, arrayval) {
      if (typeof($rootScope.brandsFobj) === 'undefined') {$rootScope.brandsFobj = [];}
      if (typeof($rootScope.priceFobj) === 'undefined') {$rootScope.priceFobj = [];}
      if (typeof($rootScope.discFobj) === 'undefined') {$rootScope.discFobj = [];}

      if (arrayval !== '' && typeof(arrayval) !== 'undefined') {
        if (ftype === 'brands') {$rootScope.brandsFobj[catId] = toObject(arrayval);}
        if (ftype === 'price') {$rootScope.priceFobj[catId] = toObject(arrayval);}
        if (ftype === 'discount') {$rootScope.discFobj[catId] = toObject(arrayval);}
      } else {
        if (ftype === 'brands') {$rootScope.brandsFobj[catId] = {};}
        if (ftype === 'price') {$rootScope.priceFobj[catId] = {};}
        if (ftype === 'discount') {$rootScope.discFobj[catId] = {};}
      }
    },
    getFilterData: function (catId, ftype) {
      if (typeof($rootScope.brandsFobj) === 'undefined') {$rootScope.brandsFobj = [];}
      if (typeof($rootScope.priceFobj) === 'undefined') {$rootScope.priceFobj = [];}
      if (typeof($rootScope.discFobj) === 'undefined') {$rootScope.discFobj = [];}

      var tval = '';
      if (ftype === 'brands') {tval = $rootScope.brandsFobj[catId];}
      if (ftype === 'price') {tval = $rootScope.priceFobj[catId];}
      if (ftype === 'discount') {tval = $rootScope.discFobj[catId];}

      if (typeof(tval) === 'undefined') {
        return '';
      } else {
        return Object.keys(tval).map(function (key) {return tval[key];});
      }
    }
  };
  return service;
});

//waze

'use strict';

angular.module('delivery.services')
.service('LocationService', function ($q) {
/*eslint-disable no-undef */
  var autocompleteService = new google.maps.places.AutocompleteService();

  var detailsService = new google.maps.places.PlacesService(document.createElement('input'));
  return {
    searchAddress: function (input) {
      var deferred = $q.defer();

      autocompleteService.getPlacePredictions({
        input: input
      }, function (result, status) {

        if (status === google.maps.places.PlacesServiceStatus.OK) {
          deferred.resolve(result);
        } else {
          deferred.reject(status);
        }
      });
      return deferred.promise;
    },
    getDetails: function (placeId) {
      var deferred = $q.defer();
      detailsService.getDetails({placeId: placeId}, function (result) {
        deferred.resolve(result);
      });
      return deferred.promise;
    }
  };
})
.directive('locationBox', function () {
  return {
    scope: {
      pholder: '@',
      resetfun: '&',
      query: '=',
      location: '='
    },
    restrict: 'E',
/*eslint-disable no-unused-vars */
    controller: function ($scope, $rootScope, $timeout) {
      var utils = this;
      $scope.btnLocClose = false;
      $scope.$watch('location', function (tmval) { if (typeof(tmval) !== 'undefined') {$scope.btnLocClose = true;}});

      $scope.resetMaster = function () {
        $scope.btnLocClose = false;
        $scope.$broadcast('clear-input');
        $scope.resetfun({data: ''});
      };
    },
    template: '<div  class="item-input-wrapper searchWrapper">' +
      '<i class="icon ion-search placeholder-icon"></i>' +
      '<input type="text" placeholder="{{pholder}}" location-suggestion location="location" ng-model="query">' +
      '<i ng-if="btnLocClose" ng-click="resetMaster();" class="icon ion-ios-close placeholder-icon"></i> ' +
      '</div>',
    replace: true
  };
})

.directive('locationSuggestion', function ($ionicModal, $timeout, LocationService) {
  return {
    restrict: 'A',
    scope: {
      location: '=',
      getlocation: '&'
    },
    link: function ($scope, element, locationCtrl) {
      //console.log('locationSuggestion started!');
      $scope.search = {};
      $scope.search.suggestions = [];
      $scope.search.query = '';
      $ionicModal.fromTemplateUrl('delivery/templates/location/location.html', {
        scope: $scope,
        focusFirstInput: true
      }).then(function (modal) {
        $scope.modal = modal;
      });
      element[0].addEventListener('focus', function (event) {
        $scope.open();
      });
      element[0].addEventListener('click', function (event) {
        $scope.open();
      });
      $scope.$watch('search.query', function (newValue) {
        if (newValue) {
          LocationService.searchAddress(newValue).then(function (result) {
            $scope.search.error = null;
            $scope.search.suggestions = result;
            $scope.btngLocClose = true;
          }, function (status) {
            $scope.search.error = 'There was an error :( ' + status;
          });
        }
        $scope.open = function () {  $scope.modal.show();  };
        $scope.close = function () { $scope.modal.hide();  };

        $scope.choosePlace = function (place) {
          LocationService.getDetails(place.place_id).then(function (location) {
            $scope.getlocation({data: location});
            $scope.location = location;
            $scope.search.query =  $scope.location.formatted_address ;
            $scope.close();
          });
        };
      });
      $scope.$on('clear-input', function () {element[0].value = '';});
    },
    controller: function ($scope, $timeout) {
      $scope.resetGlocation = function () {
        $scope.search.query = '';
        $scope.search.suggestions = '';
        $scope.btngLocClose = false;
      };
    }
  };
});

'use strict';
angular.module('delivery.services')
.factory('progressService', function ($ionicLoading) {
/*eslint-disable no-unused-vars */
  //-----------------------------------------------
  //Show and hide progress indicator for loading actions

  var service = {
    showLoader: function (text) {
      if (!text) {text = '<ion-spinner icon="spiral"></ion-spinner>';}
      $ionicLoading.show({template: text});
    },

    hideLoader: function () {
      $ionicLoading.hide();
    }
  };

  return service;
});

angular.module('delivery.services')
.factory('alertmsgService', function ($ionicPopup, $cordovaToast) {

  var service = {
    showMessage: function (msg) {
      $ionicPopup.alert({
        title: 'Information', template: msg,
        buttons: [ { text: 'OK', type: 'button-balanced', } ]
      });
    },
    tostMessage: function (msg) {
      $cordovaToast
        .showShortTop(msg)
        .then(function (success) {
            // success
        }, function (error) {
            // error
        });
    }
  };
  return service;
});

'use strict';
angular.module('delivery.services')
.factory('dashboardService', function ($http) {

  var service = {
    getBanners: function () {
      return $http.get('data/delivery/dashboard/appbanners.json');
    }
  };

  return service;
});

//waze

'use strict';
angular.module('delivery.services')
.factory('categoryService', function ($http) {

  var service = {
    getCategories: function () {
      return $http.get('data/delivery/dashboard/multicategory.json');
    }
  };

  return service;
});

'use strict';
/*eslint-disable no-unused-vars */
/*eslint-disable no-use-before-define */
/*eslint-disable no-undef */
var slidingTabsDirective = angular.module('ionic').directive('ionSlideTabs', ['$timeout', '$compile', '$interval', '$ionicSlideBoxDelegate', '$ionicScrollDelegate', '$ionicGesture', function ($timeout, $compile, $interval, $ionicSlideBoxDelegate, $ionicScrollDelegate, $ionicGesture) {
  return {
    require: '^ionSlideBox',
    restrict: 'A',
    link: function (scope, element, attrs, parent) {
      var ionicSlideBoxDelegate;
      var ionicScrollDelegate;
      var ionicScrollDelegateID;
      var slideTabs;
      var indicator;
      var slider;
      var tabsBar;
      var selectFirst = true;

      var options = {
        'slideTabsScrollable': true
      };
      var init = function () {

        if (angular.isDefined( attrs.slideTabsScrollable ) && attrs.slideTabsScrollable === 'false' ) {
          options.slideTabsScrollable = false;
        }

        var tabItems = '<li ng-repeat="(key, value) in tabs" ng-click="onTabTabbed($event, {{key}})" class="slider-slide-tab" ng-bind-html="value"></li>';

        if (options.slideTabsScrollable) {
          ionicScrollDelegateID = 'ion-slide-tabs-handle-' + Math.floor((Math.random() * 10000) + 1);
          tabsBar = angular.element('<ion-scroll delegate-handle="' + ionicScrollDelegateID + '" class="slidingTabs" direction="x" scrollbar-x="false"><ul>' + tabItems + '</ul> <div class="tab-indicator-wrapper"><div class="tab-indicator"></div></div> </ion-scroll>');
        } else {
          tabsBar = angular.element('<div class="slidingTabs"><ul>' + tabItems + '</ul> <div class="tab-indicator-wrapper"><div class="tab-indicator"></div></div> </div>');
        }

        slider = angular.element(element);

        var compiled = $compile(tabsBar);
        slider.parent().prepend(tabsBar);
        compiled(scope);
//get Tabs DOM Elements
        indicator = angular.element(tabsBar[0].querySelector('.tab-indicator'));
//get the slideBoxHandle
        var slideHandle = slider.attr('delegate-handle');
        var scrollHandle = tabsBar.attr('delegate-handle');

        ionicSlideBoxDelegate = $ionicSlideBoxDelegate;
        if (slideHandle) {
          ionicSlideBoxDelegate = ionicSlideBoxDelegate.$getByHandle(slideHandle);
        }
        selectFirst = true;
        $timeout(function () { selectFirst = false; }, 800);

        if (options.slideTabsScrollable) {
          ionicScrollDelegate = $ionicScrollDelegate;
          if (scrollHandle) {
            ionicScrollDelegate = ionicScrollDelegate.$getByHandle(scrollHandle);
          }
        }

        addEvents();
        setTabBarWidth();
        slideToCurrentPosition();
      };

      var addEvents = function () {
        ionic.onGesture('dragleft', scope.onSlideMove, slider[0]);
        ionic.onGesture('dragright', scope.onSlideMove, slider[0]);
        ionic.onGesture('release', scope.onSlideChange, slider[0]);
      };

      var setTabBarWidth = function () {

        if (!angular.isDefined(slideTabs) || slideTabs.length === 0 ) {
          return false;
        }

        tabsList = tabsBar.find('ul');
        var tabsWidth = 0;

        angular.forEach(slideTabs, function (currentElement, index) {
          var currentLi = angular.element(currentElement);
          tabsWidth += currentLi[0].offsetWidth;
        });

        if (options.slideTabsScrollable) {
          angular.element(tabsBar[0].querySelector('.scroll')).css('width', tabsWidth + 1 + 'px');
        } else {
          slideTabs.css('width', tabsList[0].offsetWidth / slideTabs.length + 'px');
        }
        slideToCurrentPosition();
      };

      var addTabTouchAnimation = function (event, currentElement) {
        var ink = angular.element(currentElement[0].querySelector('.ink'));
        if ( !angular.isDefined(ink) || ink.length === 0 ) {
          ink = angular.element('<span class="ink"></span>');
          currentElement.prepend(ink);
        }
        ink.removeClass('animate');
        if (!ink.offsetHeight && !ink.offsetWidth) {
          d = Math.max(currentElement[0].offsetWidth, currentElement[0].offsetHeight);
          ink.css('height', d + 'px');
          ink.css('width', d + 'px');
        }
        x = event.offsetX - ink[0].offsetWidth / 2;
        y = event.offsetY - ink[0].offsetHeight / 2;
        ink.css('top', y + 'px');
        ink.css('left', x + 'px');
        ink.addClass('animate');
      };

      var slideToCurrentPosition = function () {

        if (!angular.isDefined(slideTabs) || slideTabs.length === 0 ) {
          return false;
        }
        if (selectFirst) {
          var targetSlideIndex = 0;
        } else {
          /*eslint-disable no-redeclare */
          var targetSlideIndex = ionicSlideBoxDelegate.currentIndex();
        }
        var targetTab = angular.element(slideTabs[targetSlideIndex]);
        var targetLeftOffset = targetTab.prop('offsetLeft');
        var targetWidth = targetTab[0].offsetWidth;

        indicator.css({
          '-webkit-transition-duration': '300ms',
          '-webkit-transform': 'translate(' + targetLeftOffset + 'px,0px)',
          'width': targetWidth + 'px'
        });

        if (options.slideTabsScrollable && ionicScrollDelegate) {
          var scrollOffset = 40;
          ionicScrollDelegate.scrollTo(targetLeftOffset - scrollOffset, 0, true);
        }

        slideTabs.removeClass('tab-active');
        targetTab.addClass('tab-active');
      };

      var setIndicatorPosition = function (currentSlideIndex, targetSlideIndex, position, slideDirection) {

        var targetTab = angular.element(slideTabs[targetSlideIndex]);
        var currentTab = angular.element(slideTabs[currentSlideIndex]);
        var targetLeftOffset = targetTab.prop('offsetLeft');
        var currentLeftOffset = currentTab.prop('offsetLeft');
        var offsetLeftDiff = Math.abs(targetLeftOffset - currentLeftOffset);

        if ( currentSlideIndex === 0 && targetSlideIndex === ionicSlideBoxDelegate.slidesCount() - 1 && slideDirection === 'right' ||
          targetSlideIndex === 0 && currentSlideIndex === ionicSlideBoxDelegate.slidesCount() - 1 && slideDirection === 'left' ) {
          return;
        }

        var targetWidth = targetTab[0].offsetWidth;
        var currentWidth = currentTab[0].offsetWidth;
        var widthDiff = targetWidth - currentWidth;

        var indicatorPos = 0;
        var indicatorWidth = 0;

        if (currentSlideIndex > targetSlideIndex) {
          indicatorPos = targetLeftOffset - (offsetLeftDiff * (position - 1));
          indicatorWidth = targetWidth - ((widthDiff * (1 - position)));
        } else if (targetSlideIndex > currentSlideIndex) {
          indicatorPos = targetLeftOffset + (offsetLeftDiff * (position - 1));
          indicatorWidth = targetWidth + ((widthDiff * (position - 1)));
        }

        indicator.css({
          '-webkit-transition-duration': '0ms',
          '-webkit-transform': 'translate(' + indicatorPos + 'px,0px)',
          'width': indicatorWidth + 'px'
        });

        if (options.slideTabsScrollable && ionicScrollDelegate) {
          var scrollOffset = 40;
          ionicScrollDelegate.scrollTo(indicatorPos - scrollOffset, 0, false);
        }
      };

      scope.onTabTabbed = function (event, index) {
        addTabTouchAnimation(event, angular.element(event.currentTarget) );
        ionicSlideBoxDelegate.slide(index);
        slideToCurrentPosition();
      };

      scope.tabs = [];

      scope.addTabContent = function ($content) {
        scope.tabs.push($content);
        scope.$apply();
        $timeout(function () {
          slideTabs = angular.element(tabsBar[0].querySelector('ul').querySelectorAll('.slider-slide-tab'));
          slideToCurrentPosition();
          setTabBarWidth();
        });
      };

      scope.onSlideChange = function (slideIndex) {
        slideToCurrentPosition();
      };

      scope.onSlideMove = function () {
        var scrollDiv = slider[0].getElementsByClassName('slider-slide');
        var currentSlideIndex = ionicSlideBoxDelegate.currentIndex();
        var currentSlide = angular.element(scrollDiv[currentSlideIndex]);
        var currentSlideLeftOffset = currentSlide.css('-webkit-transform').replace(/[^0-9\-.,]/g, '').split(',')[0];
        var targetSlideIndex = (currentSlideIndex + 1) % scrollDiv.length;
        if (currentSlideLeftOffset > slider.prop('offsetLeft')) {
          targetSlideIndex = currentSlideIndex - 1;
          if (targetSlideIndex < 0) {
            targetSlideIndex = scrollDiv.length - 1;
          }
        }
        var targetSlide = angular.element(scrollDiv[targetSlideIndex]);
        var position = currentSlideLeftOffset / slider[0].offsetWidth;
        var slideDirection = position > 0 ? 'right' : 'left';
        position = Math.abs(position);
        setIndicatorPosition(currentSlideIndex, targetSlideIndex, position, slideDirection);
      };
      init();
    },
    controller: ['$scope', function ($scope) {
      this.addTab = function ($content) {
        $timeout(function () {
          if ($scope.addTabContent) {
            $scope.addTabContent($content);
          }
        });
      };
    }]
  };
}]);

slidingTabsDirective.directive('ionSlideTabLabel', [ function () {
  return {
    require: '^ionSlideTabs',
    link: function ($scope, $element, $attrs, $parent) {
      $parent.addTab($attrs.ionSlideTabLabel);
    }
  };
}]);

'use strict';
angular.module('delivery.directives', [])
/*eslint-disable no-unused-vars */
/*=============Master===============================*/
.directive('masterBox', function () {
  return {
    scope: {
      pholder: '@',
      searchfun: '&',
      resetfun: '&',
      query: '='
    },
    restrict: 'E',
    controller: function ($scope, $rootScope, $timeout) {
      var utils = this;
      $scope.btnMasterClose = false;
      utils.masterClose = function (status) {
        $scope.$apply(function () { $scope.btnMasterClose = status; });
      };
      utils.searchResult = function (result) { $scope.searchfun({data: result});};

      $scope.resetMaster = function () {
        $scope.btnMasterClose = false;
        $scope.$broadcast('clear-input');
        $scope.resetfun({data: ''});
      };

    },
    template: '<div  class="item-input-wrapper searchWrapper">' +
      '<i class="icon ion-search placeholder-icon"></i>' +
      '<input type="search" placeholder="{{pholder}}" ng-model="query" master-input>' +
      '<i ng-if="btnMasterClose" ng-click="resetMaster();" class="icon ion-ios-close placeholder-icon"></i> ' +
      '</div>',
    replace: true
  };
})

.directive('masterInput', function ($timeout) {
  return {
    scope: {},
    require: '^masterBox',
    restrict: 'A',
    link: function (scope, elem, attr, masterCtrl) {
      var timeout = '';
      elem.on('focus', function (event) {
        if (this.value.trim().length > 0) {masterCtrl.masterClose(true); } else {masterCtrl.masterClose(false);}
      });

      elem.on('blur', function (event) {
        $timeout(function () { masterCtrl.masterClose(false); }, 200);
      });

      elem.on('keyup', function (event) {
        if (this.value.trim().length > 0) {
          masterCtrl.masterClose(true);
        } else {
          masterCtrl.masterClose(false);
        }
//---------------------------------
        var target = this;
        if (timeout !== null) {$timeout.cancel(timeout);}
        var query = target.value;

        timeout = $timeout(function () {
          if (query.trim().length > 0) {
            masterCtrl.searchResult(query);
          }
        }, 10);
//---------------------------------
      });

      scope.$on('clear-input', function () {
        elem[0].value = '';
        $timeout(function () { elem[0].focus(); }, 200);
      });
    }
  };
})
/*=============Master Radio===============================*/
.directive('masterRadio', function () {
  return {
    scope: {
      datlist: '=',
      classname: '@',
      fieldName: '@',
      valuefun: '&'
    },
    restrict: 'E',
    controller: function ($scope) {
      var utils = this;

      $scope.radioModel = {name: null};
      $scope.$watch('radioModel.name', function () {
        $scope.valuefun({data: $scope.radioModel.name});
      });

      $scope.radioModel.name = getDefaultValue($scope.datlist);

//if($scope.datlist[0].default) $scope.radioModel.name = $scope.datlist[0].value;

    },
    template: '<ion-list class="{{classname}}">' +
      '<ion-radio ng-model="radioModel.name" name="{{fieldName}}" ng-value="\'{{Obj.label}}\'"  ng-repeat="Obj in datlist"><img ng-src="{{Obj.img}}">{{Obj.label}}</ion-radio>' +
      '</ion-list>',
    replace: true
  };
});

/*===============Functions=========================================*/
function getDefaultValue (datlist) {
  for (var i = 0; i < datlist.length; i++) {
    if (datlist[i].default) {return datlist[i].value;}
  }
  return '';
}
/*========================================================*/

'use strict';
angular.module('delivery', [
  'ionic',
  'delivery.controllers',
  'delivery.directives',
  'delivery.services',
  'ionic-material',
  'sir-accordion',
  'ionicLazyLoad',
  'ionicShop',
  'ngMessages',
  'ngStorage',
  'ngSanitize',

  'ionic-datepicker',
  // TODO: load other modules selected during generation
])
.config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
  $ionicConfigProvider.navBar.alignTitle('center'); // Align title center

  $stateProvider
    .state('app', {
      url: '/app',
      abstract: true,
      templateUrl: 'delivery/templates/menu.html',
      controller: 'AppCtrl'
    })

    .state('app.connection', {
      url: '/connection',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/connection/connection.html',
          controller: 'ConnectionCtrl'
        }
      }
    })

    .state('app.iniscreen', {
      url: '/iniscreen',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/iniscreen/iniscreen.html',
          controller: 'IniscreenCtrl'
        }
      }
    })

    .state('app.select-location', {
      url: '/select-location',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/iniscreen/select-location.html',
          controller: 'IniLocationCtrl'
        }
      }
    })

    .state('app.inisignup', {
      url: '/inisignup',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/iniscreen/inisignup.html',
          controller: 'IniSignupCtrl'
        }
      }
    })

    .state('app.inilogin', {
      url: '/inilogin',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/iniscreen/inilogin.html',
          controller: 'IniLoginCtrl'
        }
      }
    })
//-----------------
    .state('app.dashboard', {
      url: '/dashboard',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/dashboard/dashboard.html',
          controller: 'DashboardCtrl'
        }
      }
    })

    .state('app.products', {
      cache: false,
      url: '/products/:catid',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/products/products.html',
          controller: 'ProductsCtrl'
        }
      }
    })

    .state('app.search', {
      url: '/search/:catid/:catname',
      views: {
        'menuContent': {
          templateUrl: 'delivery/templates/products/products.html',
          controller: 'ProductsCtrl'
        }
      }
    })

   .state('app.products-detail', {
     url: '/products-detail/:proid',
     views: {
       'menuContent': {
         templateUrl: 'delivery/templates/products/products-detail.html',
         controller: 'ProductsDetailCtrl'
       }
     }
   })

   .state('app.filter', {
     url: '/filter/:catid',
     views: {
       'menuContent': {
         templateUrl: 'delivery/templates/products/products-filter.html',
         controller: 'ProductsFilterCtrl'
       }
     }
   })
//-----------------
   .state('app.shopping-cart', {
     cache: false,
     url: '/shopping-cart',
     views: {
       'menuContent': {
         templateUrl: 'delivery/templates/cart/cart.html',
         controller: 'CartCtrl'
       }
     }
   })

 .state('app.delivery-address', {
   cache: false,
   url: '/delivery-address',
   views: {
     'menuContent': {
       templateUrl: 'delivery/templates/cart/delivery-address.html',
       controller: 'CartDeliveryCtrl'
     }
   }
 })

  .state('app.delivery-options', {
    cache: false,
    url: '/delivery-options',
    views: {
      'menuContent': {
        templateUrl: 'delivery/templates/cart/delivery-options.html',
        controller: 'CartOptionsCtrl'
      }
    }
  })

  .state('app.place-order', {
    cache: false,
    url: '/place-order',
    views: {
      'menuContent': {
        templateUrl: 'delivery/templates/cart/place-order.html',
        controller: 'CartOrderCtrl'
      }
    }
  })

  .state('app.order-status', {
    cache: false,
    url: '/order-status/:status_id',
    views: {
      'menuContent': {
        templateUrl: 'delivery/templates/cart/order-status.html',
        controller: 'CartOrderStatusCtrl'
      }
    }
  })
//-----------------
  .state('app.orders', {
    cache: false,
    url: '/orders',
    views: {
      'menuContent': {
        templateUrl: 'delivery/templates/orders/orders.html',
        controller: 'OrdersCtrl'
      }
    }
  })


  .state('app.profile', {
    url: '/profile',
    views: {
      'menuContent': {
        templateUrl: 'delivery/templates/profile/profile.html',
        controller: 'ProfileCtrl'
      }
    }
  });
  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/connection');

}).run(function ($ionicPlatform, $rootScope, $ionicPopup, $cordovaToast) {
  $ionicPlatform.ready(function () {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
/*eslint-disable no-undef */
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }

//----------------------
    $rootScope.isCartIconVisible = false;
/*eslint-disable no-unused-vars */
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
      if (toState.name === 'app.dashboard' || toState.name === 'app.products' || toState.name === 'app.products-detail' || toState.name === 'app.filter' || toState.name === 'app.search' ) {
        $rootScope.isCartIconVisible = true;
      } else {
        $rootScope.isCartIconVisible = false;
      }
    });
//----------------------
    $rootScope.tostMsg = function (msg) {
      $cordovaToast
        .showShortTop(msg)
        .then(function (success) {
// success
        }, function (error) {
// error
        });
    };
//----------------------
    $rootScope.showAlert = function (msg) {
      $ionicPopup.alert({
        title: 'Information', template: msg, buttons: [ { text: 'OK', type: 'button-balanced', } ]
      });
    };

//----------------------
  });
});

'use strict';
angular.module('delivery.controllers', ['ionic', 'ngCordova', 'ionic-datepicker'])

.controller('AppCtrl', function ($scope, $rootScope, $filter, $state, $location, usersService, $ionicModal, $cordovaDialogs, $cordovaPush, $ionicSideMenuDelegate, categoryService, dashboardService, ionicMaterialInk) {

//---------------------
/*if ($rootScope.userData === '' || typeof($rootScope.userData) === 'undefined') {
  usersService.userDetails()
  .then(function (response) {

    if (response.data.success) {
      $rootScope.userData = response.data.data;
    }
  });
}*/
//---------------------
  $scope.popularSearch = [{heading: 'Popular Search', items: [{id: 0, title: 'Dal'}, {id: 0, title: 'Rice'}, {id: 0, title: 'Maggi'}, {id: 0, title: 'Atta'}, {id: 0, title: 'Desi Ghee'}]}];

  $scope.getSearchResult = function (keywords) {
    $scope.searchCats = $filter('filter')($scope.searchDefaultCats, { title: keywords });
    if ($scope.searchCats === '') {$scope.searchCats = '';}
  };

/*eslint-disable no-unused-vars */
  $scope.resetSearch = function (keywords) { $scope.searchCats = '';};
  $scope.searchProduct = function (catId, title) {$location.path('app/search/' + catId + '/' + title.replace('&amp;', 'and'));};
//---------------------


  $rootScope.accordionConfig = {
    debug: false, //For developing
    animDur: 300, //Animations duration minvalue is 0
    expandFirst: false, //Auto expand first item
    autoCollapse: true, //Auto collapse item flag
    watchInternalChanges: false, //watch internal attrs of the collection (false if not needed)
    headerClass: '', //Adding extra class for the headers
    beforeHeader: '', //Adding code or text before all the headers inner content
    afterHeader: '', //Adding code or text after all the headers inner content
    topContentClass: '', //Adding extra class for topContent
    beforeTopContent: '', //Adding code or text before all the topContent if present on item
    afterTopContent: '', //Adding code or text after all the topContent if present on item
    bottomContentClass: '', //Adding extra class for topContent
    beforeBottomContent: '', //Adding code or text before all the topContent if present on item
    afterBottomContent: '', //Adding code or text before all the topContent if present on item
    menuLink: '#/app/products' //Adding code or text before all the topContent if present on item
  };
//$scope.searchProduct = function(){ $state.go('app.search'); }
  $scope.viewCart = function () {$state.go('app.shopping-cart'); };

  $scope.toggleLeftSideMenu = function () {$ionicSideMenuDelegate.toggleLeft();  };

  $scope.logout = function () {
    usersService.userLogout()
      .then(function (response) {
        if (response.data.success) {
          $rootScope.userData = '';
          $location.path('app/dashboard');
        }
      }, function (error) {
        $rootScope.tostMsg(error);
        $location.path('app/iniscreen');
      });
  };

  $ionicModal.fromTemplateUrl('delivery/templates/products/products-search.html', {scope: $scope})
  .then(function (modal) {$scope.searchModal = modal; });
  $scope.searchClose = function () {
    $scope.searchModal.hide();
  };
  $scope.searchShow = function () {
    $scope.searchModal.show();
  };

  ionicMaterialInk.displayEffect();
});


'use strict';
angular.module('delivery.controllers')
.controller('ProfileCtrl', function ($scope, ionicMaterialInk) {
  ionicMaterialInk.displayEffect();
});

'use strict';
//TODO: migrar para serviço util
function getSelectedFilter (data, seletedArray, ftype) {
  angular.forEach(data, function (obj) {
    angular.forEach(seletedArray, function (id) {
      if (ftype === 'brands') {if (obj.brand_id === id) { obj.selected = true; }}
      if (ftype === 'price') {if (obj.pricefilter === id) { obj.selected = true; }}
      if (ftype === 'discount') {if (obj.discountfilter === id) { obj.selected = true; }}
    });
  });
  return data;
}
function getParentCat (results, findId) {
  for (var i = 0; i < results.length; i++) {
    if (results[i].category_id === findId) {
      //console.log(results[i].toSource());
      return results[i];
    } else {
      var subcat = results[i].subCollection;
      if ( subcat !== null) {
        for (var j = 0; j < subcat.length; j++) {
          if (subcat[j].category_id === findId) {
            //console.log(subcat[j].category_id);
            //console.log(results[i].toSource());
            return results[i];
          }
        }
      }
    }
  }
}
//----------------------
/*eslint-disable camelcase */
angular.module('delivery.controllers')
.controller('ProductsCtrl', function ($log, $scope, $rootScope, $location, $timeout, $ionicModal, $stateParams, $ionicScrollDelegate, productsService, progressService, eCart, ionicMaterialInk) {

  $scope.catId = $stateParams.catid;
  $scope.catname = $stateParams.catname;
  $log.log($scope.catname);
  $rootScope.sortProductBy = 'sort_order-ASC';
  $scope.noRecords = false;
  //----------Lasy Loading of Products---------------------------
  $scope.loadMoreProducts = function () {
    $scope.catId = 1;
    $scope.noRecords = false;
    if ($scope.catId !== 1 && $scope.catId !== 7) {
      $scope.noProductsAvailable = true;
      $scope.noRecords = true;
    } else {
      productsService.getProducts($scope.catId, $scope.catname, $scope.product_page)
      .then(function (response) {
        if (response.data.success) {
          $scope.products  = $scope.products.concat(response.data.data);
          $scope.newProducts  = $scope.newProducts.concat(response.data.latest_products);
          $scope.product_page++;
          $scope.noProductsAvailable = false;// On lasy loading.
        //$scope.$broadcast('scroll.infiniteScrollComplete');
        } else {
          $scope.noProductsAvailable = true;// Off lasy loading.
          if ($scope.product_page === 1) {$scope.noRecords = true;}
        }
/*eslint-disable no-unused-vars */
      }, function (error) {
        $scope.noProductsAvailable = true;// Off lasy loading.
      });
    }
  };

   //---------------------------
  $rootScope.showProducts = function (catId) {
    //$scope.category_id =$scope.catId;
    if (catId !== '' && typeof(catId) !== 'undefined') {$scope.catId = catId;}

    $ionicScrollDelegate.scrollTop();
    /*eslint-disable no-undef */
    $scope.selectedCat = findCategory($rootScope.accordionArray, $scope.catId);
    $scope.parentCats  = getParentCat($rootScope.accordionArray, $scope.catId);

    $scope.noProductsAvailable  = true; // Off lasy loading.
    $scope.product_page = 1;
    $scope.products   = [];
    $scope.newProducts   = [];

    $scope.loadMoreProducts();
  };
  $rootScope.showProducts();
//---------------------------
  $scope.showProductDetail = function (prodId) { $location.path('app/products-detail/' + prodId);};

   //----------Cart Process--------------------
  $scope.selectId = '';
  $scope.AddToCart = function (prodObj) {
    $scope.selectId = prodObj.id;
    $timeout(function () {$scope.selectId = '';}, 700);
    eCart.addToCart(prodObj);
    $rootScope.cartItems = eCart.cartProducts.length;
  };

  //------Sub categoryes Options-----
  $ionicModal.fromTemplateUrl('delivery/templates/products/products-cats.html', { scope: $scope })
  .then(function (modal) { $scope.categoryModal = modal; });
  $scope.catsClose = function () { $scope.categoryModal.hide(); };
  $scope.catsShow = function () { $scope.categoryModal.show(); };

  //------Sort Options-----
  $ionicModal.fromTemplateUrl('delivery/templates/products/products-sort.html', { scope: $scope })
  .then(function (modal) { $scope.sortModal = modal;});
  $scope.sortClose = function () { $scope.sortModal.hide(); };
  $scope.sortShow = function () {
    $scope.sortOptions = [
      {name: 'Default', val: 'sort_order-ASC'},
      {name: 'Product Title A to Z', val: 'name-ASC'},
      {name: 'Product Title Z to A', val: 'name-DESC'},
      {name: 'Price- Low to High', val: 'price-ASC'},
      {name: 'Price- High to Low', val: 'price-DESC'}
    ];
    $scope.sortModal.show();
  };
  $scope.setProductSort = function (data) { $rootScope.sortProductBy = data; $scope.sortModal.hide(); $scope.showProducts(); };
  $scope.pro_attr = '0-0-0';
  //-----------------------
  /*$scope.selectAttrib = function(pid,att_price,pro_price){
   var tmpArray = att_price.split("|");
   var newPrice = (parseFloat(pro_price)+parseFloat(tmpArray[3])).toFixed(2);
   console.log(tmpArray[0]+" : "+tmpArray[1]+" : "+tmpArray[2]+" : "+tmpArray[3]);

  if(tmpArray[1]>0){
   angular.element(document.querySelector('#sprice_'+pid)).addClass("hidePrice");
   angular.element(document.querySelector('#attrprice_'+pid)).removeClass("hidePrice");
   angular.element(document.querySelector('#attramt_'+pid)).html(newPrice);
   var tmp = tmpArray[0]+"|"+tmpArray[1]+"|"+tmpArray[2];
   angular.element(document.querySelector('#selectedattr_'+pid)).attr('attval',tmp);
  }else{
   angular.element(document.querySelector('#sprice_'+pid)).removeClass("hidePrice");
   angular.element(document.querySelector('#attrprice_'+pid)).addClass("hidePrice");
   angular.element(document.querySelector('#attramt_'+pid)).html('');
  angular.element(document.querySelector('#selectedattr_'+pid)).attr('attval','');
  }
  }*/
  //-----------------------

  ionicMaterialInk.displayEffect();
})

.controller('ProductsFilterCtrl', function ($scope, $rootScope, $location, $stateParams, productsService, ionicMaterialInk) {

  $scope.catId  = $stateParams.catid;

  $scope.brandFilter = [];
  $scope.priceFilter = [];
  $scope.discountFilter = [];
  productsService.getFilterOptions($scope.catId)
  .then(function (response) {

    $scope.filterData = response.data;

    $scope.brandFilter  = response.data.brands_filter;
    $scope.priceFilter  = response.data.pricefilter;
    $scope.discountFilter  = response.data.discountfilter;

    getSelectedFilter($scope.brandFilter, productsService.getFilterData($scope.catId, 'brands'), 'brands');// Select Filter values
    getSelectedFilter($scope.priceFilter, productsService.getFilterData($scope.catId, 'price'), 'price');// Select Filter values
    getSelectedFilter($scope.discountFilter, productsService.getFilterData($scope.catId, 'discount'), 'discount');// Select Filter values

  }, function (error) {
    alert('Error proudcts : ' + error);
  });

  //-------Watch filter changes------
  $scope.$watch('brandFilter|filter:{selected:true}', function (nv) { $scope.bids = nv.map(function (brand) { return brand.brand_id; });   }, true);
  $scope.$watch('priceFilter|filter:{selected:true}', function (nv) { $scope.prange_val = nv.map(function (pricerange) { return pricerange.pricefilter; });  }, true);
  $scope.$watch('discountFilter|filter:{selected:true}', function (nv) { $scope.drange_val = nv.map(function (discrange) { return discrange.discountfilter; });  }, true);
  //-----------------------
  $scope.applyFilter = function () {
    productsService.setFilterData($scope.catId, 'brands', $scope.bids);/*set barnds filters */
    productsService.setFilterData($scope.catId, 'price', $scope.prange_val);/*set price filters */
    productsService.setFilterData($scope.catId, 'discount', $scope.drange_val);/*set discount filters */

    $rootScope.showProducts($scope.catId);
    $location.path('app/products/' + $scope.catId);
  };
  $scope.resetFilter = function () {
    $rootScope.brandsFobj = [];  $rootScope.priceFobj = [];  $rootScope.discFobj = [];
    $rootScope.showProducts($scope.catId);
    $location.path('app/products/' + $scope.catId);
  };
  //-----------------------
})

.controller('ProductsDetailCtrl', function ($scope, $rootScope, $stateParams, $timeout, eCart, productsService, ionicMaterialInk) {

  productsService.getProductDetail($stateParams.proid)
  .then(function (response) {
    //alert("Success : "+response);
    $scope.productDetail = response.data.data;

  }, function (error) {
    alert('Error proudcts : ' + error);
  });

  //-------------------------------
  $scope.selectId = '';
  $scope.AddToCart = function (prodObj) {
    $scope.selectId = prodObj.id;
    $timeout(function () {$scope.selectId = '';  }, 700);
    eCart.addToCart(prodObj);
    $rootScope.cartItems = eCart.cartProducts.length;
  };
  //-------------------------------

  ionicMaterialInk.displayEffect();
});

'use strict';
angular.module('delivery.controllers')
.controller('OrdersCtrl', function ($scope, $rootScope, $ionicLoading, $ionicScrollDelegate, productsService, ionicMaterialInk) {
  ionicMaterialInk.displayEffect();
});

'use strict';
 /*eslint-disable no-unused-vars */
angular.module('delivery.controllers')
.controller('IniscreenCtrl', function ($scope, $rootScope, $location, $ionicSideMenuDelegate, $ionicHistory) {
 /*eslint-disable camelcase */


  $ionicSideMenuDelegate.canDragContent(false); // hide sidemenu

  $scope.loginButton = function () { $location.path('app/inilogin');};
  $scope.signupButton = function () { $location.path('app/inisignup');};
  $scope.skipButton = function () { $location.path('app/select-location');};
})

.controller('IniLocationCtrl', function ($scope, $rootScope, $location, $cordovaGeolocation, $timeout, usersService, progressService, $ionicSideMenuDelegate, $ionicHistory) {
  $ionicSideMenuDelegate.canDragContent(false);// hide sidemenu

  $scope.getAddress = function (attrs) {
    progressService.showLoader();

     /*eslint-disable no-undef */
    var geocoder = new google.maps.Geocoder();
    var latlng = new google.maps.LatLng(attrs.lat, attrs.lng);
    geocoder.geocode({ 'latLng': latlng }, function (results, status) {
      if (status === google.maps.GeocoderStatus.OK) {
        if (results[1]) {
          $scope.userAddress = results[1].formatted_address;
          progressService.hideLoader();
          $timeout(function () { $location.path('app/dashboard');  }, 1500);
        } else {
          $scope.userAddress = 'Location not found';
        }
      } else {
        $scope.userAddress = 'Geocoder failed due to: ' + status;
      }
    });
  };

  $scope.findLocation = function () {
    var posOptions = {timeout: 10000, enableHighAccuracy: false};
    $cordovaGeolocation
      .getCurrentPosition(posOptions)
      .then(function (position) {
        var lat  = position.coords.latitude;
        var lng = position.coords.longitude;
        $scope.getAddress({lat: lat, lng: lng});
      }, function (err) {
// error
      });
  };

  //$scope.findLocation();

  $scope.setLocation = function (data) {
    $scope.userLocation = data;
    var lng = data.geometry.location.lng();
    var lat = data.geometry.location.lat();
    $scope.userAddress  = $scope.userLocation.formatted_address;
    $timeout(function () { $location.path('app/dashboard');  }, 1000);
  };
})

.controller('IniSignupCtrl', function ($scope, $rootScope, $location, $ionicSideMenuDelegate, $ionicHistory) {
  $ionicSideMenuDelegate.canDragContent(false); // hide sidemenu

  $scope.regLocation = function (data) {
    $scope.userLocation = data;
    var lng  = data.geometry.location.lng();
    var lat  = data.geometry.location.lat();
    var lnglat = {lng: lng, lat: lat};
    $scope.iniRegister.city  = $scope.userLocation.formatted_address;
  };
  $scope.cuntryData = [{country_id: '', name: '-- Select Country --'}, {country_id: '99', name: 'India'}];
  $scope.iniRegister = {firstname: '', lastname: '', telephone: '', postcode: '', country_id: '', city: '', address_1: '', email: '', password: '', confirm: '', zone_id: '1433', agree: '1'};

  $scope.userRegister = function (form) {
    if (form.$valid) {
      $location.path('app/dashboard');
    }
  };
})
.controller('IniLoginCtrl', function ($scope, $rootScope, $location, $ionicSideMenuDelegate, $ionicHistory) {
  $ionicSideMenuDelegate.canDragContent(false);// hide sidemenu
  $scope.iniLogin = {email: '', password: ''};
  $scope.userLogin = function (form) {
    if (form.$valid) {
      if ($scope.iniLogin.email === 'sales@opensourcetechnologies.com' && $scope.iniLogin.password === 'demo1234') {
        $location.path('app/dashboard');
      } else {
        $rootScope.tostMsg('Invalid Credential');
      }
    }
  };
//-----------------------------
  $scope.iniReset = {email: ''};
  $scope.userResetPassword = function (form) {
    if (form.$valid) {
      $scope.iniReset = {email: ''};
      $rootScope.showAlert('New password has been sent to your registered email address.');
    }
  };
});

'use strict';
angular.module('delivery.controllers')
.controller('DashboardCtrl', function ($scope, $rootScope, $ionicModal, usersService, categoryService, dashboardService, ionicMaterialInk) {

//--------Get Category------------------------
  categoryService.getCategories()
    .then(function (response) {
      $rootScope.accordionArray = response.data.data;
       /*eslint-disable no-undef */
      $rootScope.searchDefaultCats = getAutoSuggest($rootScope.accordionArray);
    }, function (error) {
      $rootScope.tostMsg(error);
    });
//--------Banners------------------------
  dashboardService.getBanners()
  .then(function (response) {
    $rootScope.bannerData = response.data.appbanners.slider;
  }, function (error) {
    $rootScope.tostMsg(error);
  });
//--------Get User Data---------------------
  if ($rootScope.userData === '' || typeof($rootScope.userData) === 'undefined') {
    usersService.userDetails()
    .then(function (response) {
      if (response.success) {
        $rootScope.userData = response.data;
      }
    });
  }
//----------------------------------

  ionicMaterialInk.displayEffect();
});

'use strict';
angular.module('delivery.controllers')
.controller('ConnectionCtrl', function ($scope, $rootScope, $location, $ionicLoading, $timeout, $cordovaNetwork, $ionicSideMenuDelegate) {
  $ionicSideMenuDelegate.canDragContent(false); // hide sidemenu

  $rootScope.noConnection = false;
  document.addEventListener('deviceready', function () {
    $scope.checkConnection();
  }, false);

  $scope.checkConnection = function () {
    $ionicLoading.show({ template: '<ion-spinner icon="spiral"></ion-spinner>'});
    var isOnline = $cordovaNetwork.isOnline();
    if (isOnline) {

      $scope.noConnection = false;
      $ionicLoading.hide();
      $location.path('app/iniscreen');
    } else {
//--------------------------
      if (window.Connection) {
/*eslint-disable no-undef */
        if (navigator.connection.type === Connection.NONE) {
          $scope.noConnection = true;
          $ionicLoading.hide();
        } else {
          $scope.noConnection = false;
          $ionicLoading.hide();
          $location.path('app/iniscreen');
        }
      }
//--------------------------
    }
  };
  $location.path('app/iniscreen');
});

'use strict';
/*eslint-disable no-unused-vars */
/*eslint-disable camelcase */
/*eslint-disable no-redeclare */
angular.module('delivery.controllers')
.controller('CartCtrl', function ($scope, $rootScope, $ionicLoading, alertmsgService, $location, eCart, ionicMaterialInk) {
  $rootScope.cartRefresh  = function () {
    $scope.cartProducts = eCart.cartProducts;
    $rootScope.cartTotal = eCart.cartTotal();
    if (eCart.cartProducts.length > 0) {
      $rootScope.cartItems = eCart.cartProducts.length;
    } else {
      $rootScope.cartItems = '';
    }
  };

  $rootScope.cartRefresh();

//------------Update Qty-------------------------------
  $scope.updateQty = function (prodObj, type) {
    if (type === 'add') {
      var newqty = parseInt(prodObj.purchaseQuantity);
      eCart.addOneProduct(prodObj);
    } else {
      eCart.removeOneProduct(prodObj);
      var newqty = parseInt(prodObj.purchaseQuantity);
    }

    if (newqty > 0) {

      if (eCart.isAvailable) {
        $rootScope.cartRefresh();
      } else {
        alertmsgService.showMessage('The product become out of the stock, you can not buy more quantity of this product.');
      }
    } else {
      $scope.removeProduct(prodObj);
    }

/*if (newqty>0) {
  $rootScope.cartRefresh();
}else{
  $scope.removeProduct(prodObj);
}*/
  };
//----------Remove Item---------------------------------
  $scope.removeProduct = function (prodObj ) {
    eCart.removeProduct(prodObj);
    $rootScope.cartRefresh();
  };
//--------------------------------------------
  $scope.deliveryAddress = function () { $location.path('app/delivery-address'); };

  ionicMaterialInk.displayEffect();
})
.controller('CartDeliveryCtrl', function ($scope, $http, $rootScope, $ionicModal, $location, usersService, alertmsgService, eCart, ionicMaterialInk) {
  //------------------------------------
  //$rootScope.billingAddress = '';
  //$rootScope.shipingAddress = '';
  $scope.getBillShipAddress = function () {
    $http.get('data/delivery/product/paymentaddress.json').then(function (response) {
      if (response.data.success) {
        $scope.billAddresses = response.data.data.addresses;
        $scope.shipAddresses = response.data.data.addresses;
      } else {
        $scope.billAddresses = [];
        $scope.shipAddresses = [];
      }
    },
    function (error) {
      $rootScope.tostMsg(error);
    });

  };

  $scope.getBillShipAddress();
//------------Address Modal----------------------
  $ionicModal.fromTemplateUrl('delivery/templates/cart/add-address.html', { scope: $scope })
  .then(function (modal) { $scope.addressModal = modal; });
  $scope.AddressClose = function () { $scope.addressModal.hide(); };
  $scope.addAddress = function () {

    $scope.cuntryData = [{countryId: '', name: '-- Select Country --'}, {countryId: '99', name: 'India'}];
    usersService.getCountries()
    .then(function (response) {
      if (response.success) {
        $scope.cuntryData = $scope.cuntryData.concat(response.data);
      }
    });

    $scope.billshipAddress = {firstname: '', lastname: '', countryId: '', address_1: '', city: '', postcode: '', zone_id: '1433'};

    $scope.addressModal.show();
  };
//-----------Add Billing Address-----------------------
  $scope.saveAddress = function (form) {
    if (form.$valid) { $scope.saveBillingAddress($scope.billshipAddress); }
  };

  $scope.saveBillingAddress = function (data, stype) {
    $scope.billAddresses.push(data);
    $scope.addressModal.hide();
  };

  $scope.saveShippingAddress = function (data, stype) {
    $scope.shipAddresses.push(data);
    $scope.addressModal.hide();
  };
  //----------------------------------
  if (typeof($rootScope.billingAddress) === 'undefined') {$rootScope.billingAddress = '';}
  $scope.selectBillAddress = function (value) {

    $rootScope.billingAddress = value;
    var tmpdata = {payment_address: 'existing', address_id: value};
    //$scope.saveBillingAddress(tmpdata,'set');
  };

  //----------------------------------
  if (typeof($rootScope.shippingAddress) === 'undefined') {$rootScope.shippingAddress = '';}
  $scope.selectShipAddress = function (value) {

    $rootScope.shippingAddress = value;
    var tmpdata = {shipping_address: 'existing', address_id: value};
    //$scope.saveShippingAddress(tmpdata,'set');
  };
//----------------------------------
  $scope.deliveryOptions = function () {

    if ($rootScope.billingAddress === '' && $rootScope.shippingAddress === '') {
      alertmsgService.showMessage('Select Billing and Shipping Address.');
    } else if ($rootScope.billingAddress !== '' && $rootScope.shippingAddress === '') {
      alertmsgService.showMessage('Select Shipping Address.');
    } else if ($rootScope.billingAddress === '' && $rootScope.shippingAddress !== '') {
      alertmsgService.showMessage('Select Billing Address.');
    } else {
      $location.path('app/delivery-options');
    }
  };
//----------------------------------
  ionicMaterialInk.displayEffect();
})
.controller('CartOptionsCtrl', function ($scope, $http, $rootScope, ionicDatePicker, $ionicModal, $location, eCart, alertmsgService, ionicMaterialInk) {
  $scope.placeOrder = function () {
    if ($rootScope.shppingMethod !== '') {
      $location.path('app/place-order');
    } else {
      alertmsgService.showMessage('Select shipping method first to proceed.');
    }

  };

  $http.get('data/delivery/product/cart/shippingmethods.json')
  .then(function (response) {
    $scope.shippingData = response.data.shipping_methods;
  });

  if (typeof($rootScope.shppingMethod) === 'undefined') {$rootScope.shppingMethod = '';}
  $scope.selectShipMethod = function (data) {
    $rootScope.shppingMethod = data.code;
    $rootScope.shppingMethodData = data;
  };
  //-------------DatePicker---------------------
  var cdate = new Date();
  var nextMonth = cdate.getMonth() + 1;
  var monthEnd = new Date(cdate.getFullYear(), nextMonth + 1, 0).getDate();

  $scope.currntDate = cdate.getDate() + '-' + (cdate.getMonth() + 1) + '-' + cdate.getFullYear();

  var ipObj1 = {
    callback: function (val) {//Mandatory
      var sDate = new Date(val);
      $scope.currntDate = sDate.getDate() + '-' + (sDate.getMonth() + 1) + '-' + sDate.getFullYear();
    },
    disabledDates: [//Optional
      new Date('04-22-2016'),
      new Date('08-16-2016'),
      new Date(1439676000000)
    ],
    from: new Date(), //Optional
    to: new Date(cdate.getFullYear(), nextMonth, monthEnd), //Optional
    inputDate: new Date(), //Optional
    mondayFirst: true, //Optional
    disableWeekdays: [0], //Optional
    closeOnSelect: true, //Optional
    templateType: 'popup'//Optional
  };
  $scope.openDatePicker = function () {ionicDatePicker.openDatePicker(ipObj1);};
//----------------------------------

  ionicMaterialInk.displayEffect();
})
.controller('CartOrderCtrl', function ($scope, $http, eCart, $rootScope, $ionicModal, $location, $interval, alertmsgService, $cordovaInAppBrowser, ionicMaterialInk) {

  $scope.subTotal = $rootScope.cartTotal;
  $scope.grossTotal = parseInt($rootScope.cartTotal) + parseInt($rootScope.shppingMethodData.cost);

  $http.get('data/delivery/product/cart/paymentmethods.json')
  .then(function (response) {
    $scope.paymentOptions = response.data.payment_methods;
  }, function (error) {

  });
  //----------------------------------------
  $scope.discountData = {coupon: ''};
  $scope.getCouponDiscount = function (form) {
    alertmsgService.showMessage('Invalid Coupon Code');
  };
//------------Select Payment method----------------------------
  if (typeof($rootScope.paymentMethod) === 'undefined') {$rootScope.paymentMethod = '';}
  $scope.selectPaymentMethod = function (obj) {

    var paymentdata = {payment_method: obj.code, agree: '1', comment: obj.title};
    $rootScope.paymentMethod = obj.code;

  };
//----------------------------------------
  $scope.orderConfirm = function () {
    if ($rootScope.paymentMethod === '') {
      alertmsgService.showMessage('Please Select Payment Method.');
    } else {
      eCart.cartProducts = [];
      $rootScope.cartTotal = '';
      $rootScope.cartItems = '';
      $rootScope.paymentMethod = '';
      $rootScope.shppingMethod = '';
      $rootScope.billingAddress = '';
      $rootScope.shippingAddress = '';
      $location.path('app/order-status/1');
    }
  };
//-----------------------------------------
})
.controller('CartOrderStatusCtrl', function ($scope, $stateParams, ionicMaterialInk) {
  $scope.order_fstatus = $stateParams.status_id;
  ionicMaterialInk.displayEffect();
});

'use strict';
/*eslint-disable no-unused-vars */
(function (angular) {
  //Service Module for ionic-shop
  var app = angular.module('ionicShop.services', ['ionic']);
  //PRODUCT SERVICE HOLDING ALL ITEMS
  app.service('eCart', ['$http', function ($http) {

    this.galleryProducts = [];
    this.cartProducts = [];
    this.checkout = {};
    this.isAvailable = true;

    this.addToCart = function (product) {
      this.isAvailable = true;
      var productInCart = false;
      this.cartProducts.forEach(function (prod, index, prods) {
        if (prod.id === product.id) {
          productInCart = prod;
          return;
        }
      });

      if (productInCart) {
        this.addOneProduct(productInCart);
      } else {
        product.purchaseQuantity = 0;
        product.total = '<i class="fa fa-usd" > ' + (parseFloat(product.special) * 1) + '</i>';
        this.addOneProduct(product);
        this.cartProducts.push(product);
      }
    };

    this.removeProduct = function (product) {
      this.cartProducts.forEach(function (prod, i, prods) {
        if (product.id === prod.id) {
          this.cartProducts.splice(i, 1);
          this.updateTotal();
        }
      }.bind(this));
    };

    this.addOneProduct = function (product) {

      if (product.quantity > 0) {
        this.isAvailable = true;
        --product.quantity;
        ++product.purchaseQuantity;
        product.total = '<i class="fa fa-usd" > ' + (parseFloat(product.special) * parseInt(product.purchaseQuantity)) + '</i>';
      } else {
        this.isAvailable = false;
      }

      this.updateTotal();
    };

    this.removeOneProduct = function (product) {
      this.isAvailable = true;
      ++product.quantity;
      --product.purchaseQuantity;
      product.total = '<i class="fa fa-usd" > ' + (parseFloat(product.special) * parseInt(product.purchaseQuantity)) + '</i>';

      if (product.purchaseQuantity <= 0) {this.removeProduct(product);}

      this.updateTotal();
    };

    this.cartTotal = function () {
      var total = 0;
      if (this.cartProducts.length > 0) {
        this.cartProducts.forEach(function (prod, index, prods) {
          total += prod.special * prod.purchaseQuantity;
        });
      }

/*eslint-disable no-use-before-define */
      return formatTotal(total);
    };

    this.getProductQty = function (product) {
      var qty = 0;
      this.cartProducts.forEach(function (prod, index, prods) {
        if (prod.id === product.id) {
          qty = prod.purchaseQuantity;
        }
      });

      return qty;
    };

    var formatTotal = function (total) {
      return total.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
    };


    this.updateTotal = function () {
      this.total = this.cartTotal();
    }.bind(this);

    this.updateTotal();

    this.getProducts = function (callback) {
      $http.get('/admin/panel/products')
      .success(function (products) {
        this.galleryProducts = products;
        if (callback) {callback();}
      }.bind(this));
    };

  }]);

})(angular);

(function (angular) {

  //IONIC CART DIRECTIVE
  var app = angular.module('ionicShop.directives', ['ionic', 'ionicShop.services']);

  app.directive('ionCart', ['Products', '$templateCache', function (Products, $templateCache) {
    var link = function (scope, element, attr) {
      scope.$watch('products.length', function (newVal, oldVal) {
        Products.updateTotal();
        scope.emptyProducts = newVal > 0 ? false : true;
      });

      scope.emptyProducts = scope.products.length ? false : true;

      scope.addProduct = function (product) {
        Products.addOneProduct(product);
      };

      scope.removeProduct = function (product) {
        product.purchaseQuantity <= 1 ? Products.removeProduct(product) : Products.removeOneProduct(product);
      };
    };

    return {
      restrict: 'AEC',
      templateUrl: 'cart-item.html',
      link: link,
      scope: {
        products: '='
      }
    };
  }]);
  // IONIC CHECKOUT DIRECTIVE
  app.directive('ionCartFooter', ['$state', '$templateCache', function ($state, $templateCache) {
    var link = function (scope, element, attr) {

      element.addClass('bar bar-footer bar-dark');
      element.on('click', function (e) {
        if (scope.path) {
          $state.go(scope.path);
        }
      });

      element.on('touchstart', function () {
        element.css({opacity: 0.8});
      });

      element.on('touchend', function () {
        element.css({opacity: 1});
      });
    };

    return {
      restrict: 'AEC',
      templateUrl: 'cart-footer.html',
      scope: {
        path: '=path'
      },
      link: link
    };
  }]);

  // IONIC PURCHASE DIRECTIVE
  app.directive('ionCheckout', ['Products', '$templateCache', function (Products, $templateCache) {
    var link = function (scope, element, attr) {
      scope.$watch(function () {
        return Products.total;
      }, function () {
        scope.total = Products.total;
      });

      scope.checkout = Products.checkout;
      //*** Total sum of products in usd by default ***\\
      scope.total = Products.total;
      //*** Add address input fields when has-address attribute is on ion-purchase element ***\\
      if (element[0].hasAttribute('has-address')) {scope.hasAddressDir = true;}

      //*** Add email input field when has-email attribute is on ion-purchase element ***\\
      if (element[0].hasAttribute('has-email')) { scope.hasEmailDir = true; }

      //*** Add name input fields when has-name attribute is on ion-purchase element ***\\
      if (element[0].hasAttribute('has-name')) { scope.hasNameDir = true;}
    };

    return {
      restrict: 'AEC',
      templateUrl: 'checkout.html',
      link: link
    };
  }]);

  //IONIC PURCHASE FOOTER DIRECTIVE
  app.directive('ionCheckoutFooter', ['$compile', 'Products', 'stripeCheckout', 'CheckoutValidation', '$templateCache', function ($compile, Products, stripeCheckout, CheckoutValidation, $templateCache) {
    var link = function (scope, element, attr) {
      scope.checkout = Products.checkout;
      scope.processCheckout = stripeCheckout.processCheckout;
      scope.stripeCallback = stripeCheckout.stripeCallback;

      element.addClass('bar bar-footer bar-dark');

      element.on('click', function () {
        if (CheckoutValidation.checkAll(scope.checkout)) {
          scope.processCheckout(scope.checkout, scope.stripeCallback);
        } else {
          var ionPurchaseSpan = document.getElementsByTagName('ion-checkout')[0].children[0];
          angular.element(ionPurchaseSpan).html('You have invalid fields:').css({color: '#ED303C', opacity: 1});
        }
      });

      element.on('touchstart', function () {
        element.css({opacity: 0.8});
      });

      element.on('touchend', function () {
        element.css({opacity: 1});
      });
    };

    return {
      restrict: 'AEC',
      templateUrl: 'checkout-footer.html',
      link: link
    };
  }]);


//-------------------------------------
  app.directive('addToCartButton', function () {

    function link (scope, element, attributes) {
      element.on('click', function (event) {
        var cartElem = angular.element(document.getElementsByClassName('shopping-cart'));
        var offsetTopCart = cartElem.prop('offsetTop');
        var offsetLeftCart = cartElem.prop('offsetLeft');
        var widthCart = cartElem.prop('offsetWidth');
        var heightCart = cartElem.prop('offsetHeight');
        var imgElem = angular.element(event.target.parentNode.parentNode.childNodes[1]);
        var parentElem = angular.element(event.target.parentNode.parentNode);
        var offsetLeft = imgElem.prop('offsetLeft');
        var offsetTop = imgElem.prop('offsetTop');
        var offsetBottom = imgElem.prop('offsetBottom');
        var imgSrc = imgElem.prop('currentSrc');
        console.log(offsetLeft + ' : ' + offsetTop + ' : ' + imgSrc);
        console.log((offsetTopCart + heightCart / 2) + ' : ' + (offsetLeftCart + widthCart / 2));
        var imgClone = angular.element('<img src="' + imgSrc + '"/>');
        imgClone.css({
          'height': '150px',
          'position': 'absolute',
          'bottom': '0px',
          'right': '0px',
          'top': offsetTop + 'px',
          'left': offsetLeft + 'px',
          'opacity': 0.5
        });
        imgClone.addClass('itemaddedanimate');
        parentElem.append(imgClone);
        setTimeout(function () {
          imgClone.css({
            'height': '75px',
            'bottom': '0px',
            'right': '0px',
            'top': (offsetTopCart + heightCart / 2) + 'px',
            'left': (offsetLeftCart + widthCart / 2) + 'px',
            'opacity': 0.5
          });
        }, 500);
        setTimeout(function () {
          imgClone.css({
            'height': 0,
            'opacity': 0.5
          });
          cartElem.addClass('shakeit');
        }, 1000);
        setTimeout(function () {
          cartElem.removeClass('shakeit');
          imgClone.remove();
        }, 1500);
      });
    }

    return {
      restrict: 'E',
      link: link,
      transclude: true,
      replace: true,
      scope: {},
      template: '<button class="add-to-cart" ng-transclude></button>'
    };
  });
//-------------------------------------
})(angular);

(function (angular) {
  angular.module('ionicShop.templates', []).run(['$templateCache', function ($templateCache) {$templateCache.put('cart-footer.html', '<div class="title cart-footer">Checkout</div>');
    $templateCache.put('cart-item.html', '<div ng-if="!emptyProducts">\n  <div class="card product-card" ng-repeat="product in products track by $index">\n    <div class="item item-thumbnail-right product-item">\n      <img ng-src="{{product.images[0]}}" class="product-image" ion-product-image="product">\n      <h3 class="product-title">{{product.title}}</h3>\n      <p class="product-description">{{product.description}}</p>\n\n      <i class="icon ion-plus-round icon-plus-round" mouse-down-up ng-click="addProduct(product)"></i>\n         <span class="product-quantity">{{product.purchaseQuantity}}</span>\n      <i class="icon ion-minus-round icon-minus-round" mouse-down-up ng-click="removeProduct(product)"></i>\n\n      <span class="product-price">${{product.price}}</span>\n    </div>\n  </div>\n  <div>\n    <br><br><br><br>\n  </div>\n</div>\n\n<div class="empty-cart-div" ng-if="emptyProducts">\n  <h3 class="empty-cart-header">Your bag is empty!</h3>\n  <i class="icon ion-bag empty-cart-icon"></i>\n</div>');
    $templateCache.put('checkout-footer.html', '<div class="title purchase-footer">Pay</div>');
    $templateCache.put('checkout.html', '\n<span class="checkout-form-description">Please enter your credit card details:</span>\n\n<div class="list checkout-form">\n  <checkout-name ng-if="hasNameDir"></checkout-name>\n  <checkout-card></checkout-card>\n  <checkout-address ng-if="hasAddressDir"></checkout-address>\n  <checkout-email ng-if="hasEmailDir"></checkout-email>\n</div>\n\n<h2 class="checkout-total">Total: ${{total}}</h2>\n');
    $templateCache.put('gallery-item.html', '<div class="ion-gallery-content">\n  <div class="card gallery-card" ng-repeat="product in products track by $index">\n    <div class="item gallery-item">\n      <div class="gallery-image-div">\n        <img ng-src="{{product.images[0]}}" class="gallery-product-image">\n      </div>\n      <h3 class="gallery-product-title">{{product.title}}</h3>\n      <h3 class="gallery-product-price">${{product.price}}</h3>\n      <div class="gallery-product-add" ng-click="addToCart(product)">\n        <h3 class="gallery-product-add-title" cart-add>{{addText}}</h3>\n      </div>\n    </div>\n  </div>\n</div>');
    $templateCache.put('partials/address-line-one.html', '<label class="item item-input address-line-one">\n  <input type="text" ng-model="checkout.addressLineOne" placeholder="Address Line 1">\n</label>');
    $templateCache.put('partials/address-line-two.html', '<label class="item item-input address-line-two">\n  <input type="text" ng-model="checkout.addressLineTwo" placeholder="Address Line 2">\n</label>');
    $templateCache.put('partials/address.html', '<div class="item item-divider">Address: </div>\n<address-one-input></address-one-input>\n<address-two-input></address-two-input>\n<city-input></city-input>\n<state-input></state-input>\n<zip-input></zip-input>\n');
    $templateCache.put('partials/card-cvc-input.html', '<label class="item item-input card-cvc-input">\n  <input type="tel" ng-model="checkout.cvc" ng-focus="onCvcFocus()" ng-blur="onCvcBlur()" placeholder="CVC">\n  <i class=\"icon\" style="width: 40px; text-align: center;"></i>\n</label>');
    $templateCache.put('partials/card-exp-input.html', '<label class="item item-input card-exp-input">\n  <input type="tel" ng-model="checkout.exp" ng-focus="onExpFocus()" ng-blur="onExpBlur()" placeholder="MM/YYYY">\n  <i  class=\"icon\" style="width: 40px; text-align: center;"></i>\n</label>');
    $templateCache.put('partials/card-form.html', '<div class="item item-divider">Card Info: </div>\n<card-num-input></card-num-input>\n<card-exp-input></card-exp-input>\n<card-cvc-input></card-cvc-input>');
    $templateCache.put('partials/card-num-input.html', '<label class="item item-input card-num-input">\n  <input type="tel" ng-model="checkout.cc" ng-focus="onNumFocus()" ng-blur="onNumBlur()" placeholder="Credit Card Number">\n  <i  class=\"icon ion-card\" style="width: 40px; text-align: center;"></i>\n</label>');
    $templateCache.put('partials/cart-image-modal.html', '<div class=\"modal image-slider-modal\">\n\n  <ion-header-bar>\n    <button class=\"button button-light icon ion-ios7-undo-outline\" ng-click="closeModal()"></button>\n    <h1 class=\"title\">More Images</h1>\n    \n  </ion-header-bar>\n\n    <ion-slide-box class="image-slider-box" does-continue="true">\n      <ion-slide ng-repeat="image in product.images" class="image-ion-slide">\n        <ion-content>\n          <div class="image-slide-div">\n            <h3 class="image-slide-description">{{product.description}}</h3>\n            <img src="{{image}}" class="image-slide">\n          </div>\n        </ion-content>\n      </ion-slide>\n    </ion-slide-box>\n\n</div>');
    $templateCache.put('partials/city-input.html', '<label class="item item-input city-input">\n  <input type="text" ng-model="checkout.city" placeholder="City">\n</label>');
    $templateCache.put('partials/email-input.html', '<div class=\"item item-divider\">E-mail: </div>\n<label class=\"item item-input email-input\">\n  <input type=\"text\" ng-model=\"checkout.email\" ng-focus="onEmailFocus()" ng-blur="onEmailBlur()" placeholder=\"E-Mail\">\n  <i class=\"icon\" style="width: 40px; text-align: center;"></i>\n</label>\n\n');
    $templateCache.put('partials/first-name-input.html', '  <label class="item item-input first-name-input">\n    <input type="text" ng-model="checkout.lastName" placeholder="Last Name">\n  </label>');
    $templateCache.put('partials/last-name-input.html', '  <label class="item item-input last-name-input">\n    <input type="text" ng-model="checkout.firstName" placeholder="First Name">\n  </label>');
    $templateCache.put('partials/name-input.html', '<div class="item item-divider">Name: </div>\n<first-name-input></first-name-input>\n<last-name-input></last-name-input>');
    $templateCache.put('partials/state-input.html', '<label class="item item-input state-input">\n  <input type="text" ng-model="checkout.state" placeholder="State">\n</label>');
    $templateCache.put('partials/zipcode-input.html', '<label class="item item-input zip-code-input">\n  <input type="text" ng-model="checkout.zipcode" ng-focus="onZipFocus()" ng-blur="onZipBlur()" placeholder="Zipcode">\n  <i class="icon zip-code-input-icon" style="width: 40px; text-align: center;"></i>\n</label>');}]);
})(angular);
(function (angular) {

  var app = angular.module('ionicShop', ['ionic', 'ionicShop.services', 'ionicShop.directives', 'ionicShop.templates']);

})(angular);

'use strict';
angular.module('app', [
  // load your modules here
// starting with the main module
  'delivery',
]).run(function ($rootScope) {
  $rootScope.title = 'App Custom';
});
